package com.example.sonalverma.kidsdrawingapp;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

import static com.example.sonalverma.kidsdrawingapp.R.*;
import static com.example.sonalverma.kidsdrawingapp.R.color.*;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    CustomView customView;
    Canvas mCanvas;
    Paint clear = new Paint();
    Button btnMoveRight, btnMoveLeft, btnMoveUp, btnMoveDown, btnSpaceRight, btnSpaceLeft, btnSpaceUp, btnSpaceDown, btnSave, btnClear, btnLoad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        customView = findViewById(R.id.custom_view);

        btnMoveRight = findViewById(R.id.btnRight);
        btnMoveLeft = findViewById(R.id.btnLeft);
        btnMoveUp = findViewById(R.id.btnUp);
        btnMoveDown = findViewById(R.id.btnDown);

        btnSpaceRight = findViewById(id.btnRightSpace);
        btnSpaceLeft = findViewById(id.btnLeftSpace);
        btnSpaceUp = findViewById(id.btnUpSpace);
        btnSpaceDown = findViewById(id.btnDownSpace);

        btnSave = findViewById(R.id.btnSave);
        btnClear = findViewById(R.id.btnClear);
        btnLoad = findViewById(R.id.btnLoad);

        btnMoveRight.setOnClickListener(this);
        btnMoveLeft.setOnClickListener(this);
        btnMoveUp.setOnClickListener(this);
        btnMoveDown.setOnClickListener(this);

        btnSpaceRight.setOnClickListener(this);
        btnSpaceLeft.setOnClickListener(this);
        btnSpaceUp.setOnClickListener(this);
        btnSpaceDown.setOnClickListener(this);

        btnSave.setOnClickListener(this);
        btnClear.setOnClickListener(this);
        btnLoad.setOnClickListener(this);

    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btnRight:
                customView.moveRight();
                customView.invalidate();
                break;

            case R.id.btnLeft:
                customView.moveLeft();
                customView.invalidate();
                break;

            case R.id.btnUp:
                customView.moveUp();
                customView.invalidate();
                break;

            case R.id.btnDown:
                customView.moveDown();
                customView.invalidate();
                break;

            case R.id.btnRightSpace:
                customView.spaceRight();
                customView.invalidate();
                break;

            case R.id.btnLeftSpace:
                customView.spaceLeft();
                customView.invalidate();
                break;

            case R.id.btnUpSpace:
                customView.spaceUp();
                customView.invalidate();
                break;

            case R.id.btnDownSpace:
                customView.spaceDown();
                customView.invalidate();
                break;

            case R.id.btnClear:
                customView.clear();
                customView.invalidate();
                break;

            case R.id.btnSave:
                customView.save();
                break;

            case R.id.btnLoad:
                customView.load();
                customView.invalidate();
                break;
        }
    }
}
