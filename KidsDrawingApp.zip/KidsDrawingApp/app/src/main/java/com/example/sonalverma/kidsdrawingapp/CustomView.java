package com.example.sonalverma.kidsdrawingapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.support.annotation.Nullable;
import android.support.v4.content.res.ResourcesCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.sonalverma.kidsdrawingapp.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

public class CustomView extends View {

    private static final String TAG = CustomView.class.getName();
    private List<MatrixPoint> matrixPoints = new ArrayList<>();

    private Paint mPaint;
    private Path mPath;
    private int mDrawColor, mBackgroundColor;
    private Canvas mCanvas;
    private Bitmap mBitmap;
    Context myContext;

    Rect[][] matrix = new Rect[10][10];

    int matrixWidth, matrixHeight;

    float mX, mY;

    int columnCount = 1;
    int rowCount = 6;


    public CustomView(Context context) {

        super(context);
        myContext = context;
    }

    public CustomView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        myContext = context;

        mBackgroundColor = ResourcesCompat.getColor(getResources(),
                R.color.green, null);
        mDrawColor = ResourcesCompat.getColor(getResources(),
                R.color.white, null);

        mPath = new Path();
        mPaint = new Paint();
        mPaint.setColor(mDrawColor);
        mPaint.setAntiAlias(true);
        mPaint.setDither(true);
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setStrokeJoin(Paint.Join.ROUND);
        mPaint.setStrokeCap(Paint.Cap.ROUND);
        mPaint.setStrokeWidth(10);
    }

    public CustomView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        myContext = context;
    }

    public CustomView(Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        myContext = context;

    }

    @Override
    protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
        super.onSizeChanged(width, height, oldWidth, oldHeight);
        this.matrixWidth = width;
        this.matrixHeight = height;

        mBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        mCanvas = new Canvas(mBitmap);
        mCanvas.drawColor(mBackgroundColor);

        initMatrix();
    }


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawBitmap(mBitmap, 0, 0, null);
    }

    void moveRight() {
        if(columnCount >= 9){
            Toast.makeText(getContext(), "No way to go Ahead", Toast.LENGTH_LONG).show();
        }else {

            float previousX = mX;
            float previousY = mY;
            mPath.moveTo(mX, mY);
            this.columnCount = columnCount + 1;
            this.rowCount = rowCount;
            Rect rect = matrix[this.columnCount][this.rowCount];
            this.mX = rect.centerX();
            this.mY = rect.centerY();
            mPath.lineTo(this.mX, this.mY);
            mCanvas.drawPath(mPath, mPaint);
            matrixPoints.add(new MatrixPoint(previousX, previousY, mX, mY, mPaint, columnCount, rowCount));
        }
    }

    void moveLeft() {
        if(columnCount <= 0){
            Toast.makeText(getContext(), "No way to go Ahead", Toast.LENGTH_LONG).show();
        } else {

            float previousX = mX;
            float previousY = mY;
            mPath.moveTo(mX, mY);
            this.columnCount = columnCount - 1;
            this.rowCount = rowCount;
            Rect rect = matrix[this.columnCount][this.rowCount];
            this.mX = rect.centerX();
            this.mY = rect.centerY();
            mPath.lineTo(this.mX, this.mY);
            mCanvas.drawPath(mPath, mPaint);
            matrixPoints.add(new MatrixPoint(previousX, previousY, mX, mY, mPaint, columnCount, rowCount));
        }
    }

    void moveUp() {
        if(rowCount <= 0){
            Toast.makeText(getContext(), "No way to go Ahead", Toast.LENGTH_LONG).show();
        } else {

            float previousX = mX;
            float previousY = mY;

            mPath.moveTo(mX, mY);
            this.columnCount = columnCount;
            this.rowCount = rowCount - 1;
            Rect rect = matrix[this.columnCount][this.rowCount];
            this.mX = rect.centerX();
            this.mY = rect.centerY();
            mPath.lineTo(this.mX, this.mY);
            mCanvas.drawPath(mPath, mPaint);
            matrixPoints.add(new MatrixPoint(previousX, previousY, mX, mY, mPaint, columnCount, rowCount));
        }
    }

    void moveDown() {
        if(rowCount >= 9){
            Toast.makeText(getContext(), "No way to go Ahead", Toast.LENGTH_LONG).show();
        } else {

            float previousX = mX;
            float previousY = mY;

            mPath.moveTo(mX, mY);
            this.columnCount = columnCount;
            this.rowCount = rowCount + 1;
            Rect rect = matrix[this.columnCount][this.rowCount];
            this.mX = rect.centerX();
            this.mY = rect.centerY();
            mPath.lineTo(this.mX, this.mY);
            mCanvas.drawPath(mPath, mPaint);
            matrixPoints.add(new MatrixPoint(previousX, previousY, mX, mY, mPaint, columnCount, rowCount));
        }
    }

    void spaceRight() {
        if(columnCount >= 9){
            Toast.makeText(getContext(), "No way to go Ahead", Toast.LENGTH_LONG).show();
        }else {
            mPath.moveTo(mX, mY);
            this.columnCount = columnCount + 1;
            this.rowCount = rowCount;
            Rect rect = matrix[this.columnCount][this.rowCount];
            this.mX = rect.centerX();
            this.mY = rect.centerY();
        }

    }

    void spaceLeft() {
        if(columnCount <= 0){
            Toast.makeText(getContext(), "No way to go Ahead", Toast.LENGTH_LONG).show();
        } else {
            mPath.moveTo(mX, mY);
            this.columnCount = columnCount - 1;
            this.rowCount = rowCount;
            Rect rect = matrix[this.columnCount][this.rowCount];
            this.mX = rect.centerX();
            this.mY = rect.centerY();
        }

    }

    void spaceUp() {
        if(rowCount <= 0){
            Toast.makeText(getContext(), "No way to go Ahead", Toast.LENGTH_LONG).show();
        } else {
            mPath.moveTo(mX, mY);
            this.columnCount = columnCount;
            this.rowCount = rowCount - 1;
            Rect rect = matrix[this.columnCount][this.rowCount];
            this.mX = rect.centerX();
            this.mY = rect.centerY();
        }

    }

    void spaceDown() {
        if(rowCount >= 9){
            Toast.makeText(getContext(), "No way to go Ahead", Toast.LENGTH_LONG).show();
        } else {
            mPath.moveTo(mX, mY);
            this.columnCount = columnCount;
            this.rowCount = rowCount + 1;
            Rect rect = matrix[this.columnCount][this.rowCount];
            this.mX = rect.centerX();
            this.mY = rect.centerY();
        }

    }

    void save(){
        SharedPreferences preferences = myContext.getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(matrixPoints);
        editor.putString("json", json);
        editor.commit();
    }

    void clear(){
        Log.d(TAG, "clear");
        mPath.reset();
        mCanvas.drawColor(ResourcesCompat.getColor(getResources(),
                R.color.green, null), PorterDuff.Mode.DARKEN);

        columnCount = 1;
        rowCount = 6;

        mX = matrix[columnCount][rowCount].centerX();
        mY = matrix[columnCount][rowCount].centerY();

        matrixPoints.clear();
    }

    void load() {
        SharedPreferences preferences = myContext.getSharedPreferences("save", Context.MODE_PRIVATE);
        String json = preferences.getString("json", null);
        Gson gson = new Gson();
        ArrayList<MatrixPoint> matrixPoints = gson.fromJson(json, new TypeToken<ArrayList<MatrixPoint>>() {
        }.getType());

        matrixPoints = matrixPoints;

        int size = matrixPoints.size();
        for (int i = 0; i < size; i++) {
            MatrixPoint m = matrixPoints.get(i);
            mPath.moveTo(m.getStartX(), m.getStartY());
            mPath.lineTo(m.getEndX(), m.getEndY());
            mCanvas.drawPath(mPath, m.getColor());
            mX = m.getEndX();
            mY = m.getEndY();
            columnCount = m.getColumnCount();
            rowCount = m.getRowCount();
        }
    }

    void initMatrix(){

        Float X_PARTITION_RATIO = 1 / 10f;
        Float Y_PARTITION_RATIO = 1 / 10f;

        int x = (int) (matrixWidth * X_PARTITION_RATIO);
        int y = (int) (matrixHeight * Y_PARTITION_RATIO);

        for (int j = 0; j < 10; j++) {
            for (int i = 0; i < 10; i++) {
                Rect rec = new Rect(i * x, j * y, (i + 1) * x, (j + 1) * y);
                matrix[i][j] = rec;
            }
        }

        mX = matrix[columnCount][rowCount].centerX();
        mY = matrix[columnCount][rowCount].centerY();
    }

}
